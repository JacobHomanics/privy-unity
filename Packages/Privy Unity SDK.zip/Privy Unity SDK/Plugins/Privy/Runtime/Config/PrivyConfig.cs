namespace Privy
{
    public class PrivyConfig
    {
        public string AppId;
        public string ClientId;
        public PrivyLogLevel LogLevel = PrivyLogLevel.NONE;
    }
}