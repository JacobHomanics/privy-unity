namespace Privy
{
    public static class SdkVersion
    {
        public const string VersionNumber = "0.6.0";
    }
}