namespace Privy
{
    public enum AuthState
    {
        NotReady,
        Unauthenticated,
        Authenticated
    }
}